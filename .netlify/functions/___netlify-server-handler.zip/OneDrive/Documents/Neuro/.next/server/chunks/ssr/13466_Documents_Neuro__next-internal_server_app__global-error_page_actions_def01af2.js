module.exports=[50062,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documents_Neuro__next-internal_server_app__global-error_page_actions_def01af2.js.map