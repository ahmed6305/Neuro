module.exports=[83412,(a,b,c)=>{}];

//# sourceMappingURL=OneDrive_Documents_Neuro__next-internal_server_app_page_actions_e6b3e484.js.map