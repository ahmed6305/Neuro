module.exports=[80103,(a,b,c)=>{}];

//# sourceMappingURL=OneDrive_Documents_Neuro__next-internal_server_app_games_page_actions_ca00d763.js.map