globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/72cf961d655e9538.js",
    "static/chunks/eff75aa00f04073b.js",
    "static/chunks/09d16226e42e6eee.js",
    "static/chunks/0b1520c444b3a25a.js",
    "static/chunks/turbopack-30826de216c4b5f3.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];