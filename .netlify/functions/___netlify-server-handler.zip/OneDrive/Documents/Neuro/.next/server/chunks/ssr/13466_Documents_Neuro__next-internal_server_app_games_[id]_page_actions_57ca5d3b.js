module.exports=[11083,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documents_Neuro__next-internal_server_app_games_%5Bid%5D_page_actions_57ca5d3b.js.map