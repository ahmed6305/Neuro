module.exports=[20499,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documents_Neuro__next-internal_server_app__not-found_page_actions_2822d343.js.map