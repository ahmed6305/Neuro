module.exports=[66554,(a,b,c)=>{}];

//# sourceMappingURL=OneDrive_Documents_Neuro__next-internal_server_app_profile_page_actions_7b33f9e7.js.map